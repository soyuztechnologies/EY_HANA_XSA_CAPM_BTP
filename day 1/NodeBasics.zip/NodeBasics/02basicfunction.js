///----Basics of functions - named function
var reuse = require('./reuse');

var arr = ["apple","banana","cherry"];
var arr2 = ["miami","santa clara","las vegas"];


reuse.printf(arr);
reuse.printf(arr2);
reuse.printSize(arr);