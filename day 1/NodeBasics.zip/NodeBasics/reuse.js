module.exports = {
    printf : function(arrObject){
        for (let i = 0; i < arrObject.length; i++) {
            const element = arrObject[i];
            console.log(element);
        }
    },
    printSize : function(arrName){
        console.log('Size of this array is--===>>> ' + arrName.length);
    }
}