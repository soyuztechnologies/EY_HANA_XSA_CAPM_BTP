const express = require('express')
const app = express()
app.use(express.static('webapp'))

app.get('/', function (req, res) {
  res.send('Hello Anubhav Kem Cho!')
})

app.get("/employees", (req,res) => {
    res.json({
        "empTable": [
            { 
                "empId": 1000001,
                "empName": "Anubhav Oberoi",
                "salary": 5000,
                "currency": "USD"
            },
            { 
                "empId": 1000002,
                "empName": "Lavanya Shenoy",
                "salary": 25000,
                "currency": "USD"
            },
            { 
                "empId": 1000003,
                "empName": "Ananya Biswas",
                "salary": 21000,
                "currency": "EUR"
            }
        ],
        "cities": [
            {
                "cityName": "Jaipur",
                "state": "Rajasthan"
            },
            {
                "cityName": "Bangalore",
                "state": "Karnataka"
            },
            {
                "cityName": "Detroit",
                "state": "USA"
            },
            {
                "cityName": "Mumbai",
                "state": "Maharashtra"
            }
        ],
        "gender": {
                  "M": "Male",
                  "F": "Female"
        }
    });
});

app.listen(process.env.PORT || 3000)

console.log("server is running on http://localhost:3000")