
//Simple variable in JS
var x = 10;
console.log(x  + " is a " + typeof(x));
var y = "20";
console.log(y  + " is a " + typeof(y));
var z = parseInt(y);
console.log(z  + " is a " + typeof(z));
x = false;
console.log(x  + " is a " + typeof(x));

//Creating an array in js
let aFruits = ["Apple","Banana","Cherry"];
//Array always starts with index 0
console.log("first element : " + aFruits[0]);
//Check the length of array
console.log("length : " + aFruits.length);
//Since index starts with 0, last element will be lenhth -1
console.log("last element : " + aFruits[aFruits.length - 1]);
//add elements
aFruits.push("Litchi");
console.log(aFruits);
//Remove Last in first out
aFruits.pop();
console.log(aFruits);
//add elements in middle
aFruits.splice(1,0,"Pineapple");
console.log(aFruits);
//Remove element at index 3
aFruits.splice(2,1);
console.log(aFruits);

//Print all data of an array by loop
for (let i = 0; i < aFruits.length; i++) {
    const element = aFruits[i];
    console.log(i + "==> " + element);
}


//Objects in JS - Java Script Object Notation = JSON
var oEmp = {
    "empId": 10001,
    "empName": "Anubhav",
    "salary": 90000,
    "currency": "USD",
    "smoker": false
};

//Access a property
console.log(oEmp.empId);
//Change data
oEmp.empName = "Ananya";
console.log(oEmp);
//Its also possible to loop json
for (const key in oEmp) {
    if (oEmp.hasOwnProperty.call(oEmp, key)) {
        const element = oEmp[key];
        console.log(key + " has a value ==> " + element);
    }
}
//Convert json to string
let mystr = JSON.stringify(oEmp);
console.log(mystr);
//Convert String to json again
console.log(JSON.parse(mystr));